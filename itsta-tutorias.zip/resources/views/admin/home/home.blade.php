@extends('master.master')

@section('structure-content')


    <div class="container">
        <div class="row">
            <div class="grid">

                <div class="card-sidebar">
                    <div class="info">
                        <p>
                            Infirmacion:
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Est ad eaque labore praesentium eveniet
                            nostrum
                            debitis itaque, consequatur laboriosam autem corrupti mollitia ipsa omnis saepe ducimus
                            provident
                            molestias suscipit quod!

                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima illo pariatur similique.
                            Delectus
                            eligendi, aliquid ad culpa iste modi aliquam non quaerat. Velit eius nemo, eos dolore dolores in
                            esse!
                        </p>
                    </div>
                </div>

                <div class="card-main">

                </div>

                <div class="card-messajes">

                </div>
            </div>
        </div>

    </div>

@endsection
