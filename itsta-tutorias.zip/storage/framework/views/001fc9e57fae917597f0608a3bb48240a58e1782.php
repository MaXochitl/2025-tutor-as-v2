<div class="modal fade" id="nuevo-ingreso-edit<?php echo e($alum->id); ?>" tabindex="-1" aria-labelledby="carrera-modal"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="carrera-modal">
                    Editar: <?php echo e($alum->nombre); ?> </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php if(count($errors) > 0): ?>
                    <?php echo $__env->make('secciones.errores', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>


                <form method="POST" action="<?php echo e(route('alumnos_examenes.update', $alum->id)); ?>"
                    enctype="multipart/form-data">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="carrera" class="form-label">Carrera</label>
                        <select name="carrera" class="form-select" aria-label="Default select example">
                            <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php if($alum->carrera_id == $item->id): ?> <?php echo e('selected'); ?><?php endif; ?> value="<?php echo e($item->id); ?>">
                                    <?php echo e($item->nombre_carrera); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="form-label" class="form-label">Numero de control</label>
                        <input style="text-transform:uppercase;" name="num_control" type="text" class="form-control"
                            id="num_control" value="<?php echo e($alum->num_control); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="nombre">Nombre Completo</label>
                        <input style="text-transform:uppercase;" name="nombre" type="text" class="form-control"
                            id="nombre" value="<?php echo e($alum->nombre); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="telefono">Telefono</label>
                        <input name="telefono" type="text" class="form-control" id="telefono"
                            value="<?php echo e($alum->telefono); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="correo">Correo</label>
                        <input style="text-transform:lowercase;" name="correo" type="mail" class="form-control"
                            id="correo" value="<?php echo e($alum->correo); ?>">
                    </div>

                    <div class="form-group">
                        <div style="text-align: center">
                            <button type="submit" class="btn btn-primary" style="margin-top: 20px">Guardar</button>
                        </div>
                    </div>

                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\AREA_TRABAJO\LARAVEL\itsta-tutorias\resources\views/admin/alumnos_ni/editar.blade.php ENDPATH**/ ?>