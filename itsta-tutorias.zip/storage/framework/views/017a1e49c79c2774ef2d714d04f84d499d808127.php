<div class="modal fade" id="modal-asignacion<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="modal-eval"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5>ASIGNAR SEMESTRE Y GRUPO</h5> <br>
                <?php echo e($item->id); ?>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <p><?php echo e($item->nombre . ' ' . $item->ap_paterno . ' ' . $item->ap_materno); ?></p>
                <form method="POST" action="<?php echo e(route('asignaciones.update', $id_modal)); ?>">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="row  shadow-lg p-3 text-center">
                        <div class="col-3 col-md-6">
                            <label for="semestre">Semestre</label>
                            <select name="semestre" class="form-select" aria-label="Default select example">
                                <?php $__currentLoopData = $semestres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($items); ?> "><?php echo e($items); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-3 col-md-6">
                            <label for="grupo">Grupo</label>
                            <select name="grupo" class="form-select" aria-label="Default select example">
                                <?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($items); ?> "><?php echo e($items); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                    </div>

                    <div class="form-group ">
                        <div style="text-align: center">
                            <button type="submit" class="btn btn-primary" style="margin-top: 20px">Guardar</button>
                        </div>
                    </div>

                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\AREA_TRABAJO\LARAVEL\itsta-tutorias\resources\views/modal/asignaciones/mes_semestre.blade.php ENDPATH**/ ?>