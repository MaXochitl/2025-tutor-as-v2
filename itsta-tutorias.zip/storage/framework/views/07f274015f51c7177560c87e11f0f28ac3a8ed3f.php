<div class="modal fade" id="materiaFailed" tabindex="-1" aria-labelledby="materiaFailed" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="materiaFailed">
                    Materias
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

            </div>
            <div class="modal-body" style="text-align: left">
                <form method="POST" action="<?php echo e(route('addMateria.addMateria',[$periodo_tutorado->id,0])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <table class="table table-sm table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Materia</th>
                                <th scope="col">Semestre</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row">
                                        <label class="list-group-item">
                                            <input name="materiax[]" class="form-check-input me-1"
                                                type="checkbox" value="<?php echo e($item->id); ?> ">
                                            <?php echo e($item->nombre); ?>

                                        </label>
                                    </th>
                                    <td>
                                        <?php echo e($item->semestre); ?>

                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <div class="form-group row">
                        <div style="text-align: center">

                            <button type="submit" class="btn btn-primary" style="margin-top: 20px">Guardar</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\AREA_TRABAJO\LARAVEL\itsta-tutorias\resources\views/modal/materia/add-failed.blade.php ENDPATH**/ ?>