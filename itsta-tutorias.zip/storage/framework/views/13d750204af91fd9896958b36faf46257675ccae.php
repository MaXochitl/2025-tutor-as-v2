


<?php $__env->startSection('structure-content'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css">

    <div class="container">
        <div style="text-align: right; margin: 20px">
            <a href="<?php echo e(route('orientacion.index')); ?> ">
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40   " fill="currentColor"
                    class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                    <path
                        d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z" />
                </svg>
            </a>
        </div>
        <div class="row ">

            <div class="col d-flex flex-column flex-shrink-0" style="padding: 20px;">
                <div style="text-align: center">
                    <?php if(count($tutores)==0): ?>
                        <div class="alert alert-danger" >Actualmente no hay tutores de esta carrera</div>
                    <?php else: ?>
                    <h1>
                        Tutores de la carrera: <br> <?php echo e($tutores[0]->carrera->nombre_carrera); ?>

                    </h1>

                    <?php endif; ?>
                </div>

                <div class="row row-tutor">

                    <!--____________________________ codigo de barra de busqueda-->
                    <div class="container m-3">
                        <div class="row justify-content-end">
                            <div class="col-md-6 offset-md-3">
                                <form class="input-group" method="POST" action="<?php echo e(route('searchTutor', $carrera)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input name="search_tutor" type="text" class="form-control" placeholder="Bucar"
                                        aria-label="Buscar" id="search-input" value="<?php echo e($palabra); ?>">
                                    <div class="input-group-append">
                                        <!-- Botón de buscar -->
                                        <button class="btn btn-primary" type="submit" id="search-btn">Buscar</button>
                                        <!-- Botón de borrar datos -->
                                        <a href="<?php echo e(route('tutor.show', $carrera)); ?>" class="btn btn-danger" type="button"
                                            id="clear-btn">Borrar</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!--  _________________________________  fin de la barra de busqueda-->


                    <table id="table" class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Foto</th>
                                <th scope="col">Matricula</th>
                                <th scope="col">Carrera</th>
                                <th scope="col">Nombre Completo</th>
                                <th scope="col">Correo</th>
                                <th scope="col">Telefono</th>
                                <th scope="col">Domicilio</th>
                                <th scope="col">Alumnos</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $tutores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->carrera_id != null): ?>
                                    <tr>
                                        <td>
                                            <img src="<?php echo e($item->foto); ?> " alt="" height="50px" width="50px"
                                                class="img-icon" style="border-radius: 40px; padding: 0px ">
                                        </td>

                                        <td><?php echo e($item->id); ?> </td>
                                        <td><?php echo e($item->carrera->nombre_carrera); ?></td>
                                        <td><?php echo e($item->nombre . ' ' . $item->ap_paterno . ' ' . $item->ap_materno); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item->user->email); ?>

                                        </td>
                                        <td><?php echo e($item->telefono); ?> </td>
                                        <td><?php echo e($item->domicilio); ?> </td>
                                        <td>
                                            <a href="<?php echo e(route('alumnos-tutor.show', $item->id)); ?> "
                                                class="btn btn-primary">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30"
                                                    fill="currentColor" class="bi bi-person-lines-fill" viewBox="0 0 16 16">
                                                    <path
                                                        d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm-5 6s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zM11 3.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5zm.5 2.5a.5.5 0 0 0 0 1h4a.5.5 0 0 0 0-1h-4zm2 3a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1h-2zm0 3a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1h-2z" />
                                                </svg>
                                            </a>
                                        </td>

                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php echo e($tutores->links('pagination::bootstrap-4')); ?>

        </div>

    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>
    <script>
        /*
                                                $(document).ready(function() {
                                                    $('#table').DataTable({
                                                        //para cambiar el lenguaje a español
                                                        "language": {
                                                            "lengthMenu": "Mostrar _MENU_ registros",
                                                            "zeroRecords": "No se encontraron resultados",
                                                            "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                                                            "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                                                            "infoFiltered": "(filtrado de un total de _MAX_ registros)",
                                                            "sSearch": "Buscar:",
                                                            "oPaginate": {
                                                                "sFirst": "Primero",
                                                                "sLast": "Último",
                                                                "sNext": "Siguiente",
                                                                "sPrevious": "Anterior"
                                                            },
                                                            "sProcessing": "Procesando...",
                                                        }
                                                    });
                                                });
                                                */
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AREA_TRABAJO\LARAVEL\itsta-tutorias\resources\views/admin/tutorias/home.blade.php ENDPATH**/ ?>