<footer>


    <div class="pt-5 pb-5 footer elfooter p-3 mb-2 bg-secondary text-white">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-xs-12 about-company">
                    <h2>ITSTA</h2>
                    <p class="pr-5 text-white-50">Instituto Tecnológico Superior de Tantoyuca</p>
                    <p><a href="#"><i class="fa fa-facebook-square mr-1"></i></a><a href="#"><i
                                class="fa fa-linkedin-square"></i></a></p>
                </div>
                <div class="col-lg-3 col-xs-12">
                    <h4 class="mt-lg-0 mt-sm-3"></h4>
                    <ul class="m-0 p-0">

                        Desv. Lindero – Tametate S/N, Col. La Morita
                        CP 92100, Tantoyuca, Veracruz <br>
                        Tel. (01 789) 8931680, 8931552 <br>
                        <a style="color: white" href="https://itsta.edu.mx ">https://itsta.edu.mx </a>

                    </ul>
                </div>
                <div class="col-lg-4 col-xs-12 location">
                    <h4 class="mt-lg-0 mt-sm-4"></h4>
                    <p></i></p>
                    <p>

                        <i class="fa fa-envelope-o mr-3"></i>
                    </p>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col copyright">
                    <p class=""><small class="text-white-50">© 2021. Todos los derechos
                            reservados.</small></p>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH E:\AREA_TRABAJO\LARAVEL\itsta-tutorias\resources\views/secciones/footer.blade.php ENDPATH**/ ?>