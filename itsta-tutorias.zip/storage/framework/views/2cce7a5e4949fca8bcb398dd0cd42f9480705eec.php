<div class="row row-tutor">
    <div class="col d-flex flex-column flex-shrink-0" style="padding: 20px;">
        Lista de alumnos canalizados por los docentes que le imparten clases
        <?php if(session('hay_alumnos') == 'si'): ?>
            <div class="alert alert-danger">
                Ya esta registrado!
            </div>
        <?php endif; ?>

        <div class="overflow-scroll">
            <table class="table text-center table-striped" style="font-size: 12px">
                <thead>
                    <tr>
                        <th class="title-table" scope="col">N°</th>
                        <th class="title-table" scope="col">N° CONTROL</th>
                        <th class="title-table" scope="col">NOMBRE COMPLETO</th>
                        <th class="title-table" scope="col">TELEFONO</th>
                        <th scope="col">DOCENTE<br>1</th>
                        <th scope="col">TUTOR<br>1</th>
                        <th scope="col">DOCENTE<br>2</th>
                        <th scope="col">TUTOR<br>2</th>
                        <th scope="col">DOCENTE<br>3</th>
                        <th scope="col">TUTOR<br>3</th>
                        <th scope="col">DOCENTE<br>4</th>
                        <th scope="col">TUTOR<br>4</th>
                        <th scope="col">RESULTADOS</th>
                        <th scope="col">TUTOR</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $contador = 1;
                        $tutor_id = Auth::user()->tutor->id;


                    ?>
                    <?php if($tutorado != null): ?>
                        <?php $__currentLoopData = $docente_alumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumnos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(in_array(strtolower((string) $alumnos->alumno_id), $tutorado)): ?>
                                <tr>
                                    <th scope="row">
                                        <?php echo e($contador++); ?>

                                    </th>
                                    <td style="background: <?php echo e($alumnos->semaforo->fondo); ?> ">
                                        <p><?php echo e($alumnos->alumno->id); ?> </p>
                                    </td>
                                    <td><?php echo e($alumnos->alumno->nombre . ' ' . $alumnos->alumno->ap_paterno . ' ' . $alumnos->alumno->ap_paterno); ?>

                                    </td>
                                    <td>
                                        <?php echo e($alumnos->alumno->telefono); ?>

                                    </td>
                                    <td>
                                        <div>
                                            <?php echo e($alumnos->mes_1); ?>

                                        </div>
                                        <div class="d-grid gap-2">
                                            <?php if($alumnos->entrega_1 != null): ?>
                                                <b>
                                                    <?php
                                                        echo date('d/m/Y', strtotime($alumnos->entrega_1));
                                                    ?>
                                                </b>
                                            <?php endif; ?>
                                        </div>
                                    </td>

                                    <td>
                                        <div>
                                            <?php echo e($alumnos->oe_1); ?>

                                        </div>
                                        <?php if($fecha_actual >= $inicio && $fecha_actual <= $mes_1 || $altera_entrega->mes_1): ?>
                                            <div class="d-grid gap-2">

                                                <a href="" type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                    data-bs-target="#oe1Modal<?php echo e($alumnos->id); ?>"
                                                    data-bs-whatever="@mdo">
                                                    Seguimiento
                                                </a>
                                            </div>
                                            <?php echo $__env->make('modal.orientacion.mes1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <div>
                                            <?php echo e($alumnos->mes_2); ?>

                                        </div>

                                        <?php if($alumnos->entrega_2 != null): ?>
                                            <b>
                                                <?php
                                                    echo date('d/m/Y', strtotime($alumnos->entrega_2));
                                                ?>
                                            </b>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div>
                                            <?php echo e($alumnos->oe_2); ?>

                                        </div>
                                        <?php if($fecha_actual == $mes_2 || ($fecha_actual >= $mes_1 && $fecha_actual <= $mes_2)): ?>
                                            <div class="d-grid gap-2">
                                                <a href="" type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                    data-bs-target="#oe2Modal<?php echo e($alumnos->id); ?>"
                                                    data-bs-whatever="@mdo">
                                                    Seguimiento
                                                </a>
                                            </div>
                                            <?php echo $__env->make('modal.orientacion.mes2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endif; ?>

                                    </td>


                                    <td>
                                        <div>
                                            <?php echo e($alumnos->mes_3); ?>

                                        </div>
                                        <?php if($alumnos->entrega_3 != null): ?>
                                            <b>
                                                <?php
                                                    echo date('d/m/Y', strtotime($alumnos->entrega_3));
                                                ?>
                                            </b>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <div>
                                            <?php echo e($alumnos->oe_3); ?>

                                        </div>
                                        <?php if($fecha_actual >= $mes_2 && $fecha_actual <= $mes_3): ?>
                                            <div class="d-grid gap-2">
                                                <a href="" type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                    data-bs-target="#oe3Modal<?php echo e($alumnos->id); ?>"
                                                    data-bs-whatever="@mdo">
                                                    Seguimiento
                                                </a>
                                            </div>
                                            <?php echo $__env->make('modal.orientacion.mes3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endif; ?>
                                    </td>


                                    <td>
                                        <div>
                                            <?php echo e($alumnos->mes_4); ?>

                                        </div>

                                        <?php if($alumnos->entrega_4 != null): ?>
                                            <b>
                                                <?php
                                                    echo date('d/m/Y', strtotime($alumnos->entrega_4));
                                                ?>
                                            </b>
                                        <?php endif; ?>
                                    </td>


                                    <td>
                                        <div>
                                            <?php echo e($alumnos->oe_4); ?>

                                        </div>
                                        <?php if($fecha_actual >= $mes_3 && $fecha_actual <= $mes_4): ?>
                                            <div class="d-grid gap-2">
                                                <a href="" type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                    data-bs-target="#oe4Modal<?php echo e($alumnos->id); ?>"
                                                    data-bs-whatever="@mdo">
                                                    Seguimiento
                                                </a>
                                            </div>
                                            <?php echo $__env->make('modal.orientacion.mes4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endif; ?>


                                    </td>

                                    <td>
                                        <div>
                                            <?php echo e($alumnos->reporte_final); ?>

                                        </div>

                                        <?php if($fecha_actual >= $mes_4 && $fecha_actual <= $entrega_final): ?>
                                            <div class="d-grid gap-2">
                                                <a href="" type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                    data-bs-target="#endMatter<?php echo e($alumnos->id); ?>"
                                                    data-bs-whatever="@mdo">
                                                    Materias
                                                </a>

                                            </div>
                                            <?php echo $__env->make(
                                                'modal.materia.resultado-materia'
                                            , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($alumnos->tutor->nombre . ' ' . $alumnos->tutor->ap_paterno . ' ' . $alumnos->tutor->ap_materno); ?>

                                    </td>

                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH D:\AREA_TRABAJO\LARAVEL\itsta-tutorias\resources\views/docente_tutor/tutor.blade.php ENDPATH**/ ?>