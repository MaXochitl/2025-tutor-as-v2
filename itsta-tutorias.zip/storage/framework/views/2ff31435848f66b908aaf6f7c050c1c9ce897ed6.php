<?php
$control_materia = App\Models\Control_materia::where('alumno_id', $alumnos->alumno_id)
    ->where('periodo_id', $alumnos->periodo_id)
    ->get();
?>

<div class="modal fade" id="endMatter<?php echo e($alumnos->id); ?>" tabindex="-1" aria-labelledby="endMatter"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="new-materia-modal">
                    <b> MATERIAS</b>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

            </div>
            <div class="modal-body" style="text-align: left">
                <?php if(count($control_materia) == 0): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        No hay materias
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>

                <?php else: ?>
                    <div class="row mb-3">
                        <div class="col-6 themed-grid-col">
                            <h5><b>APROBADAS</b></h5>
                            <?php $__currentLoopData = $control_materia->where('status', 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e('* '. $item->materia->nombre); ?> <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="col-6 themed-grid-col">
                            <h5><b>REPROBADAS</b></h4>
                                <?php $__currentLoopData = $control_materia->where('status', 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php echo e('* '. $item->materia->nombre); ?> <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>



            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\AREA_TRABAJO\LARAVEL\itsta-tutorias\resources\views/modal/materia/resultado-materia.blade.php ENDPATH**/ ?>