<nav class="navbar navbar-light navbar-expand-lg">
    <div class="container-fluid">

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        </button>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.tutor', Model::class)): ?>
            <a class="navbar-brand" href="<?php echo e(route('orientacion.index')); ?>">Tutorias</a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('solo.admin')): ?>
            <a class="navbar-brand" href="<?php echo e(route('evaluacion.index')); ?> ">Nuevo Ingreso</a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('solo.tutor')): ?>
            <a class="navbar-brand" href="<?php echo e(route('alumnos.index')); ?>">Alumnos</a>
            <a class="navbar-brand" href="<?php echo e(route('materia.index')); ?>">Materias</a>
        <?php endif; ?>

        <div class="collapse navbar-collapse" id="navbarNavDropdown">
        </div>
        <div>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <?php echo $__env->make('secciones.menu_usuario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH C:\laragon\www\itsta-tutorias\resources\views/secciones/navBar.blade.php ENDPATH**/ ?>