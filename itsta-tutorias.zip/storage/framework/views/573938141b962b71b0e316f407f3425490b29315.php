
<?php $__env->startSection('structure-content'); ?>


    <div class="container">
        <?php if(session('alumno') == 'ok'): ?>
            <div class="alert alert-success">
                El alumno se agrego con exito!
            </div>
        <?php endif; ?>
        <?php if(session('existe_alumno') == 'no'): ?>
            <div class="alert alert-danger">
                No se encontro Alumno! Puedes registrarlo en la seccion nuevo alumno
            </div>
        <?php endif; ?>

        <?php if(count($alumnos_tutor) == 0): ?>
            <div style="text-align: right; margin: 20px">

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mes.tutor')): ?>
                    <button href="<?php echo e(route('alumnos-tutor.create')); ?> " type="button" class="btn btn-primary"
                        data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor"
                            class="bi bi-calendar-plus-fill" viewBox="0 0 16 16">
                            <path
                                d="M4 .5a.5.5 0 0 0-1 0V1H2a2 2 0 0 0-2 2v1h16V3a2 2 0 0 0-2-2h-1V.5a.5.5 0 0 0-1 0V1H4V.5zM16 14V5H0v9a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2zM8.5 8.5V10H10a.5.5 0 0 1 0 1H8.5v1.5a.5.5 0 0 1-1 0V11H6a.5.5 0 0 1 0-1h1.5V8.5a.5.5 0 0 1 1 0z" />
                        </svg>
                        Agregar
                    </button>
                <?php endif; ?>

            </div>
            <div class="alert alert-danger">
                No se encotraron registros!
            </div>
        <?php else: ?>
            <?php
                date_default_timezone_set('America/Mexico_City');
                
                $inicio = strtotime($periodo[0]->inicio);
                $fin = strtotime($periodo[0]->fin);
                $mes_1 = strtotime($periodo[0]->mes_1);
                $mes_2 = strtotime($periodo[0]->mes_2);
                $mes_3 = strtotime($periodo[0]->mes_3);
                $mes_4 = strtotime($periodo[0]->mes_4);
                $entrega_final = strtotime($periodo[0]->reporte_final);
                $fecha_actual = strtotime(date('Y-m-d', time()));
                
            ?>

            <div class="row img-font-all"
                style="border-radius: 10px;margin-top: 30px;background-image: url(<?php echo e($alumnos_tutor[0]->tutor->carrera->fondo); ?>);">
                <div class="col-5" style="border-radius: 10px; background: white; margin: 5px">
                    <p class="head-alumnos-tutor"><b>Nombre Tutor de grupo: </b>
                        <?php echo e($alumnos_tutor[0]->tutor->nombre .' ' .$alumnos_tutor[0]->tutor->ap_paterno .' ' .$alumnos_tutor[0]->tutor->ap_materno); ?>

                    </p>
                    <p class="head-alumnos-tutor"><b>Carrera: </b> <?php echo e($alumnos_tutor[0]->tutor->carrera->nombre_carrera); ?>

                    </p>

                    <?php if($asigno != 0): ?>
                        <p class="head-alumnos-tutor"><b>Semetre:</b>
                            <?php echo e($asignado[0]->semestre); ?> </p>
                        <p class="head-alumnos-tutor"><b>Grupo:</b> <?php echo e($asignado[0]->grupo); ?> </p>
                    <?php else: ?>
                        <div class="alert alert-danger">
                            No se ha asignado grupo
                        </div>
                    <?php endif; ?>

                    <p class="head-alumnos-tutor"><b>Telefono:</b> <?php echo e($alumnos_tutor[0]->tutor->telefono); ?> </p>

                    <?php
                        $periodo_inicio = date('d/m/Y', strtotime($alumnos_tutor[0]->periodo->inicio));
                        $periodo_fin = date('d/m/Y', strtotime($alumnos_tutor[0]->periodo->fin));
                        echo ' <b>Periodo: </b>' . $periodo_inicio . ' - ' . $periodo_fin;
                    ?>
                </div>
                <div class="col-2" style="border-radius: 10px; background: white; margin: 5px">

                    <table>
                        <tbody>
                            <tr class="new-row">
                                <th scope="col"><?php echo e('Mujeres:'); ?></th>
                                <td>
                                    <?php echo e($mujeres); ?></td>
                            </tr>

                            <tr>
                                <th scope="col"><?php echo e('Hombres:'); ?></th>
                                <td>
                                    <?php echo e($hombres); ?></td>
                            </tr>

                            <tr>
                                <th scope="col"><?php echo e('Baja Temporal:'); ?></th>
                                <td>
                                    <?php echo e($temporal); ?></td>
                            </tr>

                            <tr>
                                <th scope="col"><?php echo e('Baja:'); ?></th>
                                <td>
                                    <?php echo e($baja); ?></td>
                            </tr>

                            <tr>
                                <th scope="col"><?php echo e('Verde:'); ?></th>
                                <td>
                                    <?php echo e($verde); ?></td>
                            </tr>

                            <tr>
                                <th scope="col"><?php echo e('Amarillo:'); ?></th>
                                <td>
                                    <?php echo e($naranja); ?></td>
                            </tr>

                            <tr>
                                <th scope="col"><?php echo e('Rojo:'); ?></th>
                                <td>
                                    <?php echo e($rojo); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>
    </div>

    <div class="row row-tutor">
        <div class="col d-flex flex-column flex-shrink-0" style="padding: 20px;">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mes.tutor')): ?>
                <div class="col-5">
                    <a href="<?php echo e(route('alumnos-tutor.create')); ?> " type="button" class="btn btn-primary"
                        data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor"
                            class="bi bi-calendar-plus-fill" viewBox="0 0 16 16">
                            <path
                                d="M4 .5a.5.5 0 0 0-1 0V1H2a2 2 0 0 0-2 2v1h16V3a2 2 0 0 0-2-2h-1V.5a.5.5 0 0 0-1 0V1H4V.5zM16 14V5H0v9a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2zM8.5 8.5V10H10a.5.5 0 0 1 0 1H8.5v1.5a.5.5 0 0 1-1 0V11H6a.5.5 0 0 1 0-1h1.5V8.5a.5.5 0 0 1 1 0z" />
                        </svg>
                        Agregar
                    </a>

                    <a href="" type="button" class="btn alert-warning" data-bs-toggle="modal" data-bs-target="#avisos-modal"
                        data-bs-whatever="@mdo">
                        Avisos
                    </a>
                    <?php if(session('hay_alumnos') == 'si'): ?>
                        <div class="alert alert-danger">
                            Ya esta registrado!
                        </div>
                    <?php endif; ?>
                    <br>
                </div>
                <?php echo $__env->make('modal.avisos.avisos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <div class="overflow-scroll">
                <table class="table text-center table-striped" style="font-size: 11px">
                    <thead>
                        <tr>
                            <th class="title-table" scope="col">N°</th>
                            <th class="title-table" scope="col">N° CONTROL</th>
                            <th class="title-table" scope="col">NOMBRE COMPLETO</th>
                            <th class="title-table" scope="col">TELEFONO</th>
                            <th scope="col">MES<br>1</th>
                            <th scope="col">O.E.<br>1</th>
                            <th scope="col">MES<br>2</th>
                            <th scope="col">O.E.<br>2</th>
                            <th scope="col">MES<br>3</th>
                            <th scope="col">O.E.<br>3</th>
                            <th scope="col">MES<br>4</th>
                            <th scope="col">O.E.<br>4</th>
                            <th scope="col">RESULTADOS</th>
                            <th scope="col">OPCIONES</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $contador = 1;
                        ?>
                        <?php $__currentLoopData = $alumnos_tutor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumnos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row">
                                    <?php echo e($contador++); ?>

                                </th>
                                <td style="background: <?php echo e($alumnos->semaforo->fondo); ?> ">
                                    <p><?php echo e($alumnos->alumno->id); ?> </p>
                                </td>
                                <td><?php echo e($alumnos->alumno->nombre . ' ' . $alumnos->alumno->ap_paterno . ' ' . $alumnos->alumno->ap_paterno); ?>

                                </td>
                                <td>
                                    <?php echo e($alumnos->alumno->telefono); ?>

                                </td>
                                <td>
                                    <div>
                                        <?php echo e($alumnos->mes_1); ?>

                                    </div>
                                    <div class="d-grid gap-2">
                                        <?php if($alumnos->entrega_1 != null): ?>
                                            <b>
                                                <?php
                                                    echo date('d/m/Y', strtotime($alumnos->entrega_1));
                                                ?>
                                            </b>
                                        <?php endif; ?>

                                    </div>
                                </td>

                                <td>
                                    <div>
                                        <?php echo e($alumnos->oe_1); ?>

                                    </div>
                                    <div class="d-grid gap-2">
                                        <a href="" type="button" class="btn btn-primary seg" data-bs-toggle="modal"
                                            data-bs-target="#oe1Modal<?php echo e($alumnos->id); ?>" data-bs-whatever="@mdo">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-fill" viewBox="0 0 16 16">
                                                <path d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.5-.5V10h-.5a.499.499 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z"/>
                                              </svg>
                                        </a>
                                    </div>
                                    <?php echo $__env->make('modal.orientacion.mes1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </td>

                                <td>
                                    <div>
                                        <?php echo e($alumnos->mes_2); ?>

                                    </div>
                                    <?php if($alumnos->entrega_2 != null): ?>
                                        <b>
                                            <?php
                                                echo date('d/m/Y', strtotime($alumnos->entrega_2));
                                            ?>
                                        </b>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <div>
                                        <?php echo e($alumnos->oe_2); ?>

                                    </div>
                                    <div class="d-grid gap-2">
                                        <a href="" type="button" class="btn btn-primary seg" data-bs-toggle="modal"
                                            data-bs-target="#oe2Modal<?php echo e($alumnos->id); ?>" data-bs-whatever="@mdo">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-fill" viewBox="0 0 16 16">
                                                <path d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.5-.5V10h-.5a.499.499 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z"/>
                                              </svg>
                                        </a>
                                    </div>
                                    <?php echo $__env->make('modal.orientacion.mes2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </td>

                                <td>
                                    <div>
                                        <?php echo e($alumnos->mes_3); ?>

                                    </div>
                                    <?php if($alumnos->entrega_3 != null): ?>
                                        <b>
                                            <?php
                                                echo date('d/m/Y', strtotime($alumnos->entrega_3));
                                            ?>
                                        </b>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <div>
                                        <?php echo e($alumnos->oe_3); ?>

                                    </div>
                                    <div class="d-grid gap-2">
                                        <a href="" type="button" class="btn btn-primary seg" data-bs-toggle="modal"
                                            data-bs-target="#oe3Modal<?php echo e($alumnos->id); ?>" data-bs-whatever="@mdo">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-fill" viewBox="0 0 16 16">
                                                <path d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.5-.5V10h-.5a.499.499 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z"/>
                                              </svg>
                                        </a>
                                    </div>
                                    <?php echo $__env->make('modal.orientacion.mes3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </td>

                                <td>
                                    <div>
                                        <?php echo e($alumnos->mes_4); ?>

                                    </div>
                                    <?php if($alumnos->entrega_4 != null): ?>
                                        <b>
                                            <?php
                                                echo date('d/m/Y', strtotime($alumnos->entrega_4));
                                            ?>
                                        </b>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <div>
                                        <?php echo e($alumnos->oe_4); ?>

                                    </div>
                                    <div class="d-grid gap-2">
                                        <a href="" type="button" class="btn btn-primary seg" data-bs-toggle="modal"
                                            data-bs-target="#oe4Modal<?php echo e($alumnos->id); ?>" data-bs-whatever="@mdo">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-fill" viewBox="0 0 16 16">
                                                <path d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.5-.5V10h-.5a.499.499 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z"/>
                                              </svg>
                                        </a>
                                    </div>
                                    <?php echo $__env->make('modal.orientacion.mes4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </td>

                                <td>
                                    <div>
                                        <?php echo e($alumnos->reporte_final); ?>

                                    </div>

                                    <div class="d-grid gap-2">
                                        <a href="" type="button" class="btn btn-primary seg" data-bs-toggle="modal"
                                            data-bs-target="#endMatter<?php echo e($alumnos->id); ?>" data-bs-whatever="@mdo">
                                            Materias
                                        </a>

                                    </div>
                                    <?php echo $__env->make('modal.materia.resultado-materia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </td>
                                <td>
                                    <div>
                                        <form action="<?php echo e(route('alumnos-tutor.destroy', $alumnos->id)); ?> "
                                            class="formulario-eliminar" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <div class="btn-group">
                                                <button type="submit" class="btn btn-danger dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                    Opciones
                                                </button>
                                                <ul class="dropdown-menu">

                                                    <li>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('baja', [$alumnos->id, 2, 5])); ?>">Baja
                                                            Temporal</a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('baja', [$alumnos->id, 3, 6])); ?> ">Baja
                                                            Definitiva</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </form>
                                    </div>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="btn-regresar">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mes.admin')): ?>
                    <a class="btn btn-secondary" href="<?php echo e(route('tutor.show', $alumnos_tutor[0]->tutor->carrera->id)); ?> ">
                        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40   " fill="currentColor"
                            class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                            <path
                                d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z" />
                        </svg>
                        Regresar

                    </a>
                <?php endif; ?>

            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php echo $__env->make('modal.alumno.add-alumno', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if(session('eliminar') == 'ok'): ?>
        <script>
            Swal.fire(
                'Elimado!',
                'Tu archivo ha sido eliminado.',
                'success'
            )
        </script>
    <?php endif; ?>

    <script>
        $('.formulario-eliminar').submit(function(e) {
            e.preventDefault();


            Swal.fire({
                title: 'Estas Seguro de eliminar?',
                text: "El alumno se eliminara definitivamente",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si!'
            }).then((result) => {
                if (result.isConfirmed) {

                    this.submit();
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\itsta-tutorias\resources\views/tutor-alumno/tutor-alumnos.blade.php ENDPATH**/ ?>