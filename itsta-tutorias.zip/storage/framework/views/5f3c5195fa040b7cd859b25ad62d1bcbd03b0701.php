


<?php $__env->startSection('structure-content'); ?>
    <?php
    date_default_timezone_set('America/Mexico_City');
    setlocale(LC_ALL, 'es_ES');
    $diassemana = ['Domingo', 'Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sábado'];
    $meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

    ?>


    <div class="container">
        <div style="text-align: right; margin: 20px">
            <a href="<?php echo e(route('evaluacion.index')); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40   " fill="currentColor"
                    class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                    <path
                        d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z" />
                </svg>
            </a>
        </div>
        <div class="row ">

            <div class="col d-flex flex-column flex-shrink-0" style="padding: 20px;">
                <div style="text-align: center">
                    <h1>
                        Resultados De Evaluaciones
                    </h1>
                </div>

                <div class="container p-2">
                    <form action="<?php echo e(route('evaluacion.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row shadow-lg p-3">
                            <div class="col-6 col-md-4">
                                <label for="periodo">Selecciona un periodo</label>
                                <select name="periodo" class="form-select" aria-label="Default select example">
                                    <?php $__currentLoopData = $periodo_evaluacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $inicio = date('d', strtotime($item->inicio)) . ' ' . $meses[date('n', strtotime($item->inicio)) - 1] . '  ' . date('Y', strtotime($item->inicio));
                                            $fin = date('d', strtotime($item->fin)) . ' ' . $meses[date('n', strtotime($item->fin)) - 1] . '  ' . date('Y', strtotime($item->fin));
                                        ?>
                                        <option <?php if($periodo == $item->id): ?><?php echo e('selected'); ?><?php endif; ?> value="<?php echo e($item->id); ?> ">
                                            <?php echo e($inicio . ' - ' . $fin); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-6 col-md-5">
                                <label for="carrera">Selecciona una carrera</label>
                                <select name="carrera" class="form-select" aria-label="Default select example">
                                    <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option <?php if($carrera_select == $item->id): ?><?php echo e('selected'); ?><?php endif; ?> value="<?php echo e($item->id); ?> ">
                                            <?php echo e($item->nombre_carrera); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-6 col-md-3 " style="margin-top: 21px">
                                <button type="submit" class="btn btn-primary">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor"
                                        class="bi bi-search" viewBox="0 0 16 16">
                                        <path
                                            d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                                    </svg></button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="overflow-scroll" style="height: 500px">

                    <table class="table table-striped text-center" style="border-collapse: collapse; font-size: 13px">
                        <thead>
                            <tr>
                                <th rowspan="2" scope="col">N° CONTROL</th>
                                <th rowspan="2" scope="col">NOMBRE</th>
                                <th rowspan="2" scope="col">CARRERA</th>
                                <th rowspan="2" scope="col">TELEFONO</th>
                                <th rowspan="2" scope="col">CORREO</th>
                                <th colspan="6" scope="col">PSICOMETRICO</th>
                                <th rowspan="2" scope="col">RAZONAMIENTO Y HABILIDADES</th>
                                <th rowspan="2" scope="col">SOCIOECONOMICO</th>
                                <th rowspan="2" scope="col">test de colores</th>

                            </tr>
                            <tr>
                                <th scope="col">I</th>
                                <th scope="col">II</th>
                                <th scope="col">III</th>
                                <th scope="col">IV</th>
                                <th scope="col">V</th>
                                <th scope="col">VI</th>

                            </tr>
                        </thead>

                        <tbody>

                            <?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row">
                                        <?php echo e($item->alumno->id); ?>

                                    </th>
                                    <td>
                                        <?php echo e($item->alumno->nombre . ' ' . $item->alumno->ap_paterno . ' ' . $item->alumno->ap_materno); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->alumno->carrera->nombre_carrera); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->alumno->telefono); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->alumno->correo); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->psicometrico_I); ?>


                                    </td>

                                    <td>
                                        <?php echo e($item->psicometrico_II); ?>


                                    </td>
                                    <td>
                                        <?php echo e($item->psicometrico_III); ?>


                                    </td>
                                    <td>
                                        <?php echo e($item->psicometrico_IV); ?>


                                    </td>
                                    <td>
                                        <?php echo e($item->psicometrico_V); ?>


                                    </td>
                                    <td>
                                        <?php echo e($item->psicometrico_VI); ?>


                                    </td>


                                    <td>
                                        <?php echo e($item->razonamiento); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->socioeconomico); ?>

                                    </td>
                                    <?php
                                        $color = App\Models\Posicion::where('alumno_id', $item->alumno->id)
                                            ->where('posicion', 1)
                                            ->get();
                                    ?>
                                    <?php if(count($color) == 0): ?>
                                        <td>
                                            <?php echo e('Pendiente'); ?>

                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <a class="rounded-circle btn btn-primary" href="" type="button"
                                                style="border-radius: 6px ;height: 50px; width: 50px; background: <?php echo e($color[0]->color->codigo); ?>;"
                                                data-bs-toggle="modal"
                                                data-bs-target="#res-color-modal<?php echo e($item->alumno_id); ?>"
                                                data-bs-whatever="@mdo"></a>
                                            <br>

                                        </td>

                                        <?php echo $__env->make('modal.resultados.modal-color', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                    <?php endif; ?>


                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                    <?php if(count($resultados) == 0): ?>
                        <div class="alert alert-danger">
                            Ningun Alumno ha realizado el examen!
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\AREA_TRABAJO\LARAVEL\itsta-tutorias\resources\views/admin/evaluacion/resultados/resultados.blade.php ENDPATH**/ ?>