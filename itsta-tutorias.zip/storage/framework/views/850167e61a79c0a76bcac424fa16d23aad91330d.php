<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        nombre:<?php echo e($item->alumno->nombre); ?>

        <br>
        <?php if(count($item->lights) > 0): ?>
            <?php echo e($item->lights[0]->semestre); ?>

            <br>
            <?php echo e($item->lights[0]->semaforos[0]->nombre); ?>

            <br>
            <?php echo e($item->lights[1]->semestre); ?>

            <br>
            <?php echo e($item->lights[1]->semaforos[0]->nombre); ?>

            <br>
            <?php echo e($item->lights[2]->semestre); ?>

            <br>
            <?php echo e($item->lights[2]->semaforos[0]->nombre); ?>

            <br>
            <?php echo e($item->lights[3]->semestre); ?>

            <br>
            <?php echo e($item->lights[3]->semaforos[0]->nombre); ?>

            <br>

        <?php endif; ?>
        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>

</html>
<?php /**PATH E:\AREA_TRABAJO\LARAVEL\itsta-tutorias\resources\views/test/test.blade.php ENDPATH**/ ?>