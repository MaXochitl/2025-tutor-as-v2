<div class="modal fade" id="month3Modal<?php echo e($alumnos->id); ?>" tabindex="-1" aria-labelledby="monthModal" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="month3Modal<?php echo e($alumnos->id); ?>">
                    Alumno <?php echo e($alumnos->alumno->nombre . ' ' . $alumnos->alumno->ap_paterno . ' ' . $alumnos->alumno->ap_paterno); ?>

                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <h2><b>Mes 3</b></h2> 
            <div class="modal-body">
                <?php if(count($errors) > 0): ?>
                    <?php echo $__env->make('secciones.errores', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>


                <form id="formUpdate" method="POST" action="<?php echo e(route('seguimiento-alumno.seguimiento',[$alumnos->id,3])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                        <label for="seguimiento" class="col-form-label">Describe al alumno:</label>
                        <input name="seguimiento" type="text" class="form-control" value="<?php echo e($alumnos->mes_3); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="color" class="col-form-label">Color</label>
                        <select name="color" class="form-select" aria-label="Default select example">
                            <?php $__currentLoopData = $semaforo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\AREA_TRABAJO\LARAVEL\itsta-tutorias\resources\views/modal/meses/mes3.blade.php ENDPATH**/ ?>