


<?php $__env->startSection('structure-content'); ?>


    <div class="container">

        <div style="text-align: right; margin: 20px">
            <a href="<?php echo e(route('evaluacion.index')); ?> ">
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40   " fill="currentColor"
                    class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                    <path
                        d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z" />
                </svg>
            </a>
        </div>
        <div class="row ">

            <div class="col d-flex flex-column flex-shrink-0" style="padding: 20px;">
                <div style="text-align: center">
                    <h1>
                        LISTA DE COLORES
                    </h1>
                </div>
                <div class="overflow-scroll" style="height: 500px">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">COLOR</th>
                                <th scope="col">DESCRIPCIÓN</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $colores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>

                                    <td>
                                        <div class="btn "
                                            style="background: <?php echo e($item->codigo); ?>; width: 80px; height: 90px;"></div>
                                    </td>
                                    <td>
                                        <p>
                                            <?php echo e($item->caracteristicas); ?>

                                        </p>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AREA_TRABAJO\LARAVEL\itsta-tutorias\resources\views/admin/evaluacion/colores/colores.blade.php ENDPATH**/ ?>