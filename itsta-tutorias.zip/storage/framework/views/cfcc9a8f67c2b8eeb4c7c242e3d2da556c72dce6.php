<?php

use App\Models\Carrera;
$carreras = Carrera::all();
?>

<div class="modal fade" id="alumnoedit-modal<?php echo e($alum->id); ?>" tabindex="-1" aria-labelledby="alumnoedit-modal"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">

                <h5 class="modal-title" id="alumnoedit-modal">
                    Editar Alumno
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php if(count($errors) > 0): ?>
                    <?php echo $__env->make('secciones.errores', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>

                <form action="<?php echo e(route('alumnos.update', $alum->id)); ?>" method="post">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group ">
                        <label for="ncontrol" class="form-label">Numero Control</label>
                        <input name="ncontrol" type="text" class="form-control" id="ncontrol"
                            value="<?php echo e($alum->id); ?>">
                    </div>

                    <div class="form-group ">
                        <label for="nombre" class="form-label">Nombre</label>
                        <input name="nombre" type="text" class="form-control" id="nombre"
                            value="<?php echo e($alum->nombre); ?>">
                    </div>

                    <div class="form-group ">
                        <label for="ap_paterno" class="form-label">Apellido Paterno</label>
                        <input name="ap_paterno" type="text" class="form-control" id="ap_paterno"
                            value="<?php echo e($alum->ap_paterno); ?>">
                    </div>

                    <div class="form-group ">
                        <label for="ap_materno" class="form-label">Apellido Materno</label>
                        <input name="ap_materno" type="text" class="form-control" id="ap_materno"
                            value="<?php echo e($alum->ap_materno); ?>">
                    </div>


                    <div class="form-group ">
                        <label for="carrera" class="form-label">Carrera</label>
                        <select name="carrera" class="form-select" aria-label="Default select example">
                            <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php if($alum->carrera_id == $item->id): ?> <?php echo e('selected'); ?><?php endif; ?> value="<?php echo e($item->id); ?>">
                                    <?php echo e($item->nombre_carrera); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group ">
                        <label for="sexo" class="form-label">Sexo</label>
                        <select name="sexo" class="form-select" aria-label="Default select example">
                            <option <?php if($alum->sexo == 'F'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="F">Femenino</option>
                            <option <?php if($alum->sexo == 'M'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="M">Masculino</option>
                        </select>
                    </div>

                    <div class="form-group ">
                        <label for="nacimiento" class="form-label">Fecha Nacimiento</label>
                        <input name="nacimiento" type="date" class="form-control" id="nacimiento"
                            value="<?php echo e($alum->fecha_nacimiento); ?>">
                    </div>

                    <div class="form-group ">
                        <label for="domicilio" class="form-label">Domicilio</label>
                        <input name="domicilio" type="text" class="form-control" id="domicilio"
                            value="<?php echo e($alum->domicilio); ?>">
                    </div>

                    <div class="form-group ">
                        <label for="grupo" class="form-label">Grupo</label>

                        <select name="grupo" class="form-select" aria-label="Default select example">
                            <option <?php if($alum->grupo == 'A'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="A">A</option>
                            <option <?php if($alum->grupo == 'B'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="B">B</option>
                            <option <?php if($alum->grupo == 'C'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="C">C</option>
                            <option <?php if($alum->grupo == 'D'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="D">D</option>
                            <option <?php if($alum->grupo == 'E'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="E">E</option>
                            <option <?php if($alum->grupo == 'F'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="F">F</option>
                            <option <?php if($alum->grupo == 'G'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="G">G</option>
                            <option <?php if($alum->grupo == 'H'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="H">H</option>
                            <option <?php if($alum->grupo == 'I'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="I">I</option>
                            <option <?php if($alum->grupo == 'J'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="J">J</option>
                            <option <?php if($alum->grupo == 'K'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="K">K</option>
                            <option <?php if($alum->grupo == 'L'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="L">L</option>
                            <option <?php if($alum->grupo == 'M'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="M">M</option>
                            <option <?php if($alum->grupo == 'N'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="N">N</option>
                            <option <?php if($alum->grupo == 'Ñ'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="Ñ">Ñ</option>
                            <option <?php if($alum->grupo == 'O'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="O">O</option>
                        </select>
                    </div>


                    <div class="form-group ">
                        <label for="phone" class="form-label">Telefono</label>
                        <input name="telefono" type="text" class="form-control" id="phone"
                            value="<?php echo e($alum->telefono); ?>">
                    </div>

                    <div class="form-group ">
                        <label for="estado" class="form-label">Estado</label>
                        <select name="estado" class="form-select" aria-label="Default select example">
                            <option <?php if($alum->estado == '1'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="1">Activo</option>
                            <option <?php if($alum->estado == '2'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="2">Baja Temporal</option>
                            <option <?php if($alum->estado == '3'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="3">Baja Definitiva</option>

                        </select>
                    </div>


                    <div class="form-group ">
                        <label for="correo" class="form-label">Correo</label>
                        <input name="correo" type="email" class="form-control" id="mail"
                            value="<?php echo e($alum->correo); ?>">
                    </div>

                    <div class="form-group ">
                        <div style="text-align: center">
                            <button type="submit" class="btn btn-primary" style="margin-top: 20px">Guardar</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
<?php /**PATH C:\laragon\www\itsta-tutorias\resources\views/modal/alumno/editar.blade.php ENDPATH**/ ?>