<div class="modal fade" id="res-color-modal<?php echo e($item->alumno_id); ?>" tabindex="-1" aria-labelledby="carrera-modal"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="carrera-modal">
                    Definición Color: <?php echo e($color[0]->color->nombre); ?>

                </h5> <br> <br>
                <?php echo e($item->alumno->nombre . ' ' . $item->alumno->ap_paterno . ' ' . $item->ap_materno); ?>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p style="text-align: justify">
                    <?php echo e($color[0]->color->caracteristicas); ?>

                </p>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\AREA_TRABAJO\LARAVEL\itsta-tutorias\resources\views/modal/resultados/modal-color.blade.php ENDPATH**/ ?>