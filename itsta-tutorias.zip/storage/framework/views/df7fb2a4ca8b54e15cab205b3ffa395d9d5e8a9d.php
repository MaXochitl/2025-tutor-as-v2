
<?php $__env->startSection('structure-content'); ?>

    <div class="container" style="margin-top: 10px">
        <div class="row col-md-10 text-center shadow-lg p-3 mb-5 bg-body rounded " style="margin: auto">
            <h4>Reporte final de: </h4>
            <h4><?php echo e($periodo_tutorado->alumno->nombre . ' ' . $periodo_tutorado->alumno->ap_paterno . ' ' . $periodo_tutorado->alumno->ap_materno); ?>

            </h4>

            <div class="row m-2">

                <div class="col">
                    <div class="d-grid gap-2 col-6 mx-auto">
                        <label for="">Materias Aprobadas</label>
                        <a href="" type="button" class="btn btn-primary" data-bs-toggle="modal"
                            data-bs-target="#materiaModal" data-bs-whatever="@mdo">
                            Agregar
                        </a>
                        <?php if(count($materia_aprobadas) != 0): ?>
                            <table class="table table-sm table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">Materia</th>
                                        <th scope="col">Quitar</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $materia_aprobadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approved): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row">
                                                <?php echo e($approved->materia->nombre); ?>

                                            </th>

                                            <td>
                                                <form
                                                    action="<?php echo e(route('removMateria.removMateria', [$periodo_tutorado->id, $approved->id])); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-outline-danger">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25"
                                                            fill="currentColor" class="bi bi-x-square-fill"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm3.354 4.646L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 1 1 .708-.708z" />
                                                        </svg>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        <?php endif; ?>
                        <?php echo $__env->make('modal.materia.add-approved', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>

                </div>
                <div class="col">
                    <div class="d-grid gap-2 col-6 mx-auto">
                        <label for="">Materias Reprobadas</label>
                        <a href="<?php echo e(route('alumnos-tutor.create')); ?> " type="button" class="btn btn-primary"
                            data-bs-toggle="modal" data-bs-target="#materiaFailed" data-bs-whatever="@mdo">
                            Agregar
                        </a>
                        <?php if(count($materia_reprobadas) != 0): ?>

                            <table class="table table-sm table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">Materia</th>
                                        <th scope="col">Quitar</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $materia_reprobadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $failed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row">
                                                <?php echo e($failed->materia->nombre); ?>

                                            </th>

                                            <td>
                                                <form
                                                    action="<?php echo e(route('removMateria.removMateria', [$periodo_tutorado->id, $failed->id])); ?> "
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>

                                                    <button type="submit" class="btn btn-outline-danger">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25"
                                                            fill="currentColor" class="bi bi-x-square-fill"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm3.354 4.646L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 1 1 .708-.708z" />
                                                        </svg>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                        <?php echo $__env->make('modal.materia.add-failed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
            <div class="form-group  col-md-6 row " style="margin: auto">
                <form method="POST" action="<?php echo e(route('seguimiento-alumno.seguimiento', [$periodo_tutorado->id, 5])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div>
                        <label for="seguimiento">Describe Reporte</label>
                        <textarea style="text-align: left" name="seguimiento" class="form-control"
                            placeholder="Describe reporte"
                            id="seguimiento"><?php echo e($periodo_tutorado->reporte_final); ?></textarea>
                    </div>
                    <div>
                        <label for="color" class="col-form-label">Color</label>
                        <select name="color" class="form-select" aria-label="Default select example">
                            <?php $__currentLoopData = $semaforo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group row">
                        <div style="text-align: center">
                            <a href="<?php echo e(route('reportes_tutor.show', $periodo_tutorado->tutor_id)); ?>" type="buutton"
                                class="btn btn-danger" style="margin-top: 20px">Cancelar</a>
                            <button type="submit" class="btn btn-primary" style="margin-top: 20px">Guardar</button>
                        </div>
                    </div>
                </form>


            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\AREA_TRABAJO\LARAVEL\itsta-tutorias\resources\views/tutor-alumno/end-report.blade.php ENDPATH**/ ?>